<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 
/*
	google-analytics.com
*/
if (LOCALHOST) return; ?>
