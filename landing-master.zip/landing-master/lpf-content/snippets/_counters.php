<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 
/*
	counters
*/
if (LOCALHOST) return; ?>
