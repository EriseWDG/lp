<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

define("SNIPPETS_DIR", PAGES_DIR . CURRENT_PAGE_ROOT . DIRECTORY_SEPARATOR . 'snippets' . DIRECTORY_SEPARATOR);
define("SNIPPETS_URL", PAGES_URL . CURRENT_PAGE_ROOT . '/snippets/');

# end of file