<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="layout-center mar20-t">

<form method="post" class="b-center w300px bg-gray200 pad20-rl pad10-t pad5-b">
	<p><label>Login<br><input type="text" value="" name="flogin_user" class="w100" placeholder="you login"></label></p>
	<p><label>Password<br><input type="password" value="" name="flogin_password" class="w100" placeholder="you password"></label></p>
	<p><button type="submit" name="flogin_submit" class="button w100">Login</button></p>
</form>

</div>