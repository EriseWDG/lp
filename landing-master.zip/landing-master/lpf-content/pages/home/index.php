<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 
/* ===

TITLE: Landing Page Framework

META:
	description: Landing Page Framework
	keywords: lLanding page,  php-framework
	viewport: width=device-width, initial-scale=1.0
	generator: Landing Page Framework (lpf.maxsite.com.ua)

VAR:
	simple: true
	compress_text: true

=== */

?>

h1 Landing Page Framework

_ <a href="http://lpf.maxsite.com.ua/">Homesite</a>

_ <a href="<?= BASE_URL ?>lpf-admin">Admin panel</a> (Put you login/password to <b>pages/lpf-admin/auth/auth-options.php</b>)
