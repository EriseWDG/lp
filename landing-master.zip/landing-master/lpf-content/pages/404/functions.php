<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

header('HTTP/1.0 404 Not Found');
