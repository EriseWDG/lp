<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

/* ===

TITLE: 404 — Not found

META:
	description: Landing Page Framework
	keywords: lLanding page, php-framework
	viewport: width=device-width, initial-scale=1.0
	generator: Landing Page Framework (lpf.maxsite.com.ua)

VAR:
	compress_text: true
	
=== */

?>

<h1>404 — Not found</h1>

<p><a href="<?= BASE_URL ?>">Home</a></p>
