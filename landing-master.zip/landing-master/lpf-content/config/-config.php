<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 
/* 
	rename this file in config.php 
*/

// main file «text.php» (for LPF < 30.0)
$MSO['_page_file'] = 'text.php';

# end of file