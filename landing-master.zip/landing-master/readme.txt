(c) Landing Page Framework (LPF) — http://lpf.maxsite.com.ua/
(c) MAX — http://maxsite.org/


Quick start

1. Download the latest release.
2. Type in your browser: http://you_site/
3. Done!
